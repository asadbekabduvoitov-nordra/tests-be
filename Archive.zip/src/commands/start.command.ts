// # /start, /help, /profile, etc.
export const startCommand = [
		{ command: "start", description: "Test botni ishga tushurish" },
		{ command: "/yonalishlar", description: "Mavjud yo'nalishlar ro'yxati" },
		{ command: "/testhelp", description: "Test boyicha qo'shimcha yordam" },
	];