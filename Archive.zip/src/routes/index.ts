import test from "./test";
import quiz from "./quiz";
import permission from "./permission";

export {
test,
quiz,
permission,
};
