export const messages = {
	start: `🎉 Xush kelibsiz!

	Siz QuizBotga muvaffaqiyatli ulanishingiz! Bu bot orqali siz turli yo‘nalishlardagi qiziqarli testlarni yechishingiz va bilimlaringizni sinovdan o‘tkazishingiz mumkin.
	
	🧠 Qoidalar:
	
	Har bir testni boshlaganingizda sizga faqat 3 ta urinish beriladi.
	
	Urinishlar tugagach, test yakunlanadi — shuning uchun har bir savolga diqqat bilan yondoshing!
	
	👇 Quyidagi menyudan birini tanlang:
	
	📚 Mavjud Yo'nalishlar — mavjud test yo‘nalishlari bilan tanishish va boshlash.
	
	📞 Biz bilan bog'lanish — savol yoki takliflaringiz bo‘lsa.
	
	Omad tilaymiz! 🚀`,
};
